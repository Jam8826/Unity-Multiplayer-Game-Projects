﻿// Cristian Pop - https://boxophobic.com/

using UnityEngine;

namespace Boxophobic.StyledGUI
{
    public class StyledInteractive : PropertyAttribute
    {
        public StyledInteractive()
        {

        }
    }
}

