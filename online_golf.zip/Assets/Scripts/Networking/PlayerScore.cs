using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct PlayerScore
{
	public float timeTaken;
	public float shotsTaken;
}
